# Traverse Ethiopia: fixes pack

Drop these files into the root of the repo (same level as `index.html`). Nothing here overwrites your
existing `css/` or `js/` files: new files are named `gallery-v2.*` and `inquiry-form.js`.

## What is in it

| File | What it does |
| --- | --- |
| `gallery.html`, `css/gallery-v2.css`, `js/gallery-v2.js` | New gallery page. Real photographs, filter by stop, keyboard-friendly viewer, dead images are dropped instead of showing a broken box. **Replaces your current `gallery.html`.** |
| `data/gallery.json` | The photo list. 14 real photographs from Wikimedia Commons (Lalibela, Simien/highlands, Blue Nile Falls, Danakil). This is the "database" for the gallery. |
| `server.js`, `lib/handlers.js` | Backend for Railway or any Node host. Serves the site plus `/api/gallery`, `/api/inquiry`, `/api/health`. No npm dependencies. |
| `api/gallery.js`, `api/inquiry.js`, `api/health.js` | The same backend as Vercel functions. Vercel picks up the `api/` folder automatically. |
| `js/inquiry-form.js`, `contact-form-snippet.html` | A working contact / trip-inquiry form wired to `/api/inquiry`. |
| `scripts/check-links.js` | Scans every `.html`/`.css` file for broken links, missing images, dead `#anchors`, `<img>` without alt, and placeholder-image hosts (picsum, placehold, etc.). |
| `scripts/verify-images.js` | Checks that every gallery photo still loads (needs internet). |

## Steps

1. Copy everything into the repo root. Accept the replacement of `gallery.html`.
2. Add these to `package.json` (keep your existing entries):
   ```json
   "scripts": {
     "start": "node server.js",
     "check:links": "node scripts/check-links.js",
     "check:images": "node scripts/verify-images.js"
   },
   "engines": { "node": ">=18" }
   ```
3. Run `npm run check:links`. It lists every broken link and image in the site so you can fix each one, including any
   image that is not a real Ethiopia photo (it flags placeholder hosts). Run `npm run check:images` with internet on.
4. In `contact.html`, replace the form with `contact-form-snippet.html` and add
   `<script src="js/inquiry-form.js" defer></script>` before `</body>`.
5. Set the inquiry destination (at least one) in Railway or Vercel environment variables:

   | Variable | Purpose |
   | --- | --- |
   | `RESEND_API_KEY`, `INQUIRY_FROM_EMAIL`, `INQUIRY_TO_EMAIL` | Emails each inquiry to you through Resend. |
   | `INQUIRY_WEBHOOK_URL` | Posts each inquiry as JSON to Formspree, Make, Zapier, Slack, etc. |
   | `INQUIRY_FILE` | Railway/VPS only: path on a persistent volume. Default `data/inquiries.jsonl`. |

   Vercel's disk is read-only, so on Vercel you must set the email or webhook variables. With none set, the form
   tells the visitor it could not save the inquiry instead of pretending it worked.

## Tested

- Server: health, gallery filter, valid/invalid inquiry, spam trap, rate limit (5 per 10 min per IP), oversized body,
  wrong methods, and blocked access to `server.js`, `lib/`, `.git`, `package.json`, stored inquiries and path traversal.
- Vercel handlers with mocked requests.
- Gallery page in a headless browser: filter, deep links (`gallery.html#danakil`), viewer with arrow keys and Escape,
  a failing image is removed, no horizontal scroll at 390px wide.
- Not tested here: live loading of the Wikimedia images (the test environment has no internet) and real email delivery.

## Limits you should know about

- I could not open your existing HTML/CSS/JS, so this pack does not edit your other pages. Their broken links and images
  are found by `npm run check:links`, not fixed by it.
- Photos are linked from Wikimedia Commons under open licences. Each photo has an "Author and licence" link in the viewer.
  For a commercial site, check each file page and credit as required, or download the originals into `img/` and
  self-host them.
- Only Lalibela, the highlands, the Blue Nile Falls and the Danakil have photos so far. Gondar, Axum, Harar, the Omo Valley,
  birding and coffee still need entries. Add them to `data/gallery.json` using the exact Commons file name, add a new
  entry to `stops`, then run `npm run check:images`.
