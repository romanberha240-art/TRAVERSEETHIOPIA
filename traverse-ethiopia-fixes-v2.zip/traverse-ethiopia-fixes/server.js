'use strict';

/**
 * Traverse Ethiopia server (Railway, Render, a VPS, or `node server.js` locally).
 * Serves the static site and the JSON API. No npm dependencies. Node 18+.
 *
 *   GET  /api/health
 *   GET  /api/gallery[?stop=lalibela]
 *   POST /api/inquiry
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { getGallery, handleInquiry } = require('./lib/handlers');

const ROOT = __dirname;
const PORT = Number(process.env.PORT) || 3000;
const MAX_BODY = 20 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
};

// Never serve server code, dependencies, or stored inquiries.
const BLOCKED_SEGMENTS = new Set(['lib', 'api', 'scripts', 'node_modules', '.git', 'server.js', 'package.json', 'package-lock.json', 'railway.json', 'nixpacks.toml']);

function send(res, status, body, headers) {
  const h = Object.assign({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin' }, headers);
  res.writeHead(status, h);
  res.end(body);
}

function sendJson(res, status, obj) {
  send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooBig = false;
    const chunks = [];
    req.on('data', (c) => {
      if (tooBig) return; // keep draining so the 413 response can be delivered
      size += c.length;
      if (size > MAX_BODY) {
        tooBig = true;
        reject(Object.assign(new Error('Payload too large'), { status: 413 }));
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => { if (!tooBig) resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', reject);
  });
}

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

async function handleApi(req, res, url) {
  if (url.pathname === '/api/health') return sendJson(res, 200, { ok: true });

  if (url.pathname === '/api/gallery') {
    if (req.method !== 'GET') return sendJson(res, 405, { ok: false, error: 'Method not allowed' });
    const payload = getGallery({ stop: url.searchParams.get('stop') });
    return send(res, 200, JSON.stringify(payload), {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'public, max-age=300',
    });
  }

  if (url.pathname === '/api/inquiry') {
    if (req.method !== 'POST') {
      res.setHeader('Allow', 'POST');
      return sendJson(res, 405, { ok: false, error: 'Method not allowed' });
    }
    let raw;
    try {
      raw = await readBody(req);
    } catch (err) {
      res.setHeader('Connection', 'close');
      res.on('finish', () => req.destroy());
      return sendJson(res, err.status || 400, { ok: false, error: err.message });
    }
    const { status, json } = await handleInquiry({ body: raw, ip: clientIp(req) });
    return sendJson(res, status, json);
  }

  return sendJson(res, 404, { ok: false, error: 'Not found' });
}

function resolveFile(pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch (e) {
    return null;
  }
  const rel = path.normalize(decoded).replace(/^([/\\])+/, '');
  const segments = rel.split(path.sep).filter(Boolean);
  if (segments.some((s) => s.startsWith('.') || BLOCKED_SEGMENTS.has(s))) return null;

  const abs = path.join(ROOT, rel);
  if (!abs.startsWith(ROOT)) return null;

  const candidates = [abs, abs + '.html', path.join(abs, 'index.html')];
  for (const c of candidates) {
    try {
      if (fs.statSync(c).isFile() && MIME[path.extname(c).toLowerCase()]) return c;
    } catch (e) { /* try next */ }
  }
  return null;
}

function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed', { Allow: 'GET, HEAD' });
  const file = resolveFile(url.pathname);
  if (!file) {
    const notFound = path.join(ROOT, '404.html');
    if (fs.existsSync(notFound)) return send(res, 404, fs.readFileSync(notFound), { 'Content-Type': MIME['.html'] });
    return send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
  const ext = path.extname(file).toLowerCase();
  const headers = {
    'Content-Type': MIME[ext],
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=86400',
  };
  if (req.method === 'HEAD') return send(res, 200, '', headers);
  fs.readFile(file, (err, data) => (err ? send(res, 500, 'Server error') : send(res, 200, data, headers)));
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) {
    handleApi(req, res, url).catch((err) => {
      console.error('[api] unhandled:', err);
      sendJson(res, 500, { ok: false, error: 'Server error' });
    });
    return;
  }
  serveStatic(req, res, url);
});

server.listen(PORT, () => console.log('Traverse Ethiopia listening on port ' + PORT));
