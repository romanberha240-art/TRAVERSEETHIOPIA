'use strict';

/**
 * Scans every .html and .css file for broken local links, missing images,
 * dead #anchors, missing alt text, and placeholder-image hosts.
 * Offline, no dependencies.
 *
 *   node scripts/check-links.js          (exit code 1 if anything is broken)
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SKIP_DIRS = new Set(['node_modules', '.git', '.vercel', 'scripts']);
const PLACEHOLDER_HOSTS = /(picsum\.photos|placehold\.co|placeholder\.com|placekitten|loremflickr|lorempixel|dummyimage|source\.unsplash\.com\/random|fakeimg)/i;

function walk(dir, out) {
  for (const name of fs.readdirSync(dir)) {
    if (SKIP_DIRS.has(name)) continue;
    const full = path.join(dir, name);
    const st = fs.statSync(full);
    if (st.isDirectory()) walk(full, out);
    else if (/\.(html|css)$/i.test(name)) out.push(full);
  }
  return out;
}

const rel = (p) => path.relative(ROOT, p) || '.';
const isExternal = (u) => /^(https?:)?\/\//i.test(u);
const isIgnorable = (u) => !u || /^(mailto:|tel:|sms:|javascript:|data:|blob:|#$)/i.test(u);

function resolveLocal(fromFile, url) {
  const clean = url.split('#')[0].split('?')[0];
  if (!clean) return fromFile; // pure #anchor
  let base = clean.startsWith('/') ? path.join(ROOT, clean) : path.resolve(path.dirname(fromFile), clean);
  try { base = decodeURIComponent(base); } catch (e) { /* keep raw */ }
  for (const c of [base, base + '.html', path.join(base, 'index.html')]) {
    try { if (fs.statSync(c).isFile()) return c; } catch (e) { /* next */ }
  }
  return null;
}

const idCache = new Map();
function idsIn(file) {
  if (!idCache.has(file)) {
    const ids = new Set();
    if (/\.html$/i.test(file)) {
      const html = fs.readFileSync(file, 'utf8');
      for (const m of html.matchAll(/\s(?:id|name)\s*=\s*["']([^"']+)["']/gi)) ids.add(m[1]);
    }
    idCache.set(file, ids);
  }
  return idCache.get(file);
}

function refsFromHtml(html) {
  const refs = [];
  const attr = /\b(href|src|poster|data-src|data-bg|action)\s*=\s*("([^"]*)"|'([^']*)')/gi;
  for (const m of html.matchAll(attr)) refs.push({ kind: m[1].toLowerCase(), url: (m[3] ?? m[4] ?? '').trim() });
  for (const m of html.matchAll(/\bsrcset\s*=\s*("([^"]*)"|'([^']*)')/gi)) {
    (m[2] ?? m[3] ?? '').split(',').forEach((part) => {
      const u = part.trim().split(/\s+/)[0];
      if (u) refs.push({ kind: 'srcset', url: u });
    });
  }
  for (const m of html.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/gi)) refs.push({ kind: 'css-url', url: m[1].trim() });
  return refs;
}

const problems = [];
const warnings = [];

for (const file of walk(ROOT, [])) {
  const text = fs.readFileSync(file, 'utf8');
  const isHtml = /\.html$/i.test(file);
  const refs = isHtml ? refsFromHtml(text) : [...text.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/gi)].map((m) => ({ kind: 'css-url', url: m[1].trim() }));

  for (const { kind, url } of refs) {
    if (isIgnorable(url)) continue;
    if (isExternal(url)) {
      if (PLACEHOLDER_HOSTS.test(url)) problems.push(`${rel(file)}: placeholder image host (${kind}) -> ${url}`);
      continue;
    }
    if (url.startsWith('/api/')) continue; // served by the backend
    // Files that live next to CSS are resolved relative to the CSS file, as browsers do.
    const target = resolveLocal(file, url);
    if (!target) {
      problems.push(`${rel(file)}: broken ${kind} -> ${url}`);
      continue;
    }
    const hash = url.includes('#') ? url.split('#')[1].split('?')[0] : '';
    if (hash && /\.html$/i.test(target) && !idsIn(target).has(hash)) {
      problems.push(`${rel(file)}: missing anchor #${hash} in ${rel(target)}`);
    }
  }

  if (isHtml) {
    for (const m of text.matchAll(/<img\b[^>]*>/gi)) {
      const tag = m[0];
      if (!/\balt\s*=/i.test(tag)) warnings.push(`${rel(file)}: <img> without alt -> ${(tag.match(/src\s*=\s*["']([^"']+)/i) || [, '?'])[1]}`);
    }
  }
}

if (warnings.length) {
  console.log('\nWarnings (' + warnings.length + ')');
  warnings.forEach((w) => console.log('  - ' + w));
}
if (problems.length) {
  console.log('\nBroken (' + problems.length + ')');
  problems.forEach((p) => console.log('  x ' + p));
  process.exit(1);
}
console.log('\nNo broken local links, images or anchors found.');
