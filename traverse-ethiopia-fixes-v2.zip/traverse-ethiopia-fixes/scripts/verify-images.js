'use strict';

/**
 * Checks that every photograph in data/gallery.json still resolves to a real
 * image on Wikimedia Commons. Needs internet access and Node 18+.
 *
 *   node scripts/verify-images.js
 */

const gallery = require('../data/gallery.json');

const IMG_BASE = 'https://commons.wikimedia.org/wiki/Special:FilePath/';
const stops = new Set(gallery.stops.map((s) => s.id));

async function check(img) {
  const url = IMG_BASE + encodeURIComponent(img.file.replace(/ /g, '_')) + '?width=480';
  try {
    const res = await fetch(url, { method: 'GET', redirect: 'follow', headers: { 'User-Agent': 'TraverseEthiopiaImageCheck/1.0' } });
    const type = res.headers.get('content-type') || '';
    if (!res.ok) return `HTTP ${res.status}`;
    if (!type.startsWith('image/')) return `not an image (${type || 'no content-type'})`;
    return null;
  } catch (err) {
    return 'network error: ' + err.message;
  }
}

(async () => {
  let failed = 0;
  const seen = new Set();
  for (const img of gallery.images) {
    const issues = [];
    if (!stops.has(img.stop)) issues.push(`unknown stop "${img.stop}"`);
    if (seen.has(img.id)) issues.push('duplicate id');
    seen.add(img.id);
    if (!img.alt) issues.push('missing alt text');
    const problem = await check(img);
    if (problem) issues.push(problem);

    if (issues.length) {
      failed++;
      console.log(`x ${img.id}: ${issues.join('; ')}`);
    } else {
      console.log(`ok ${img.id}`);
    }
  }
  console.log(`\n${gallery.images.length - failed} of ${gallery.images.length} photographs OK.`);
  process.exit(failed ? 1 : 0);
})();
