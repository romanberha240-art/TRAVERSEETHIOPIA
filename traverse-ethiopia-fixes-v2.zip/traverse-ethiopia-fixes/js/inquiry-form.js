(function () {
  'use strict';

  var form = document.querySelector('form[data-inquiry]');
  if (!form) return;

  var statusEl = form.querySelector('[data-inquiry-status]');
  if (!statusEl) {
    statusEl = document.createElement('p');
    statusEl.setAttribute('data-inquiry-status', '');
    form.appendChild(statusEl);
  }
  statusEl.setAttribute('role', 'status');
  statusEl.setAttribute('aria-live', 'polite');

  var button = form.querySelector('button[type="submit"], input[type="submit"]');

  // Lets a "Book this trip" button on an itinerary page link straight here with
  // the tour pre-selected, e.g. contact.html?tour=Omo%20Valley%20cultural%20tour
  (function preselectTour() {
    var params = new URLSearchParams(location.search);
    var wanted = params.get('tour');
    if (!wanted) return;
    var select = form.elements['tour'];
    if (!select) return;
    var match = Array.prototype.find.call(select.options, function (o) {
      return o.value.toLowerCase() === wanted.toLowerCase() || o.textContent.toLowerCase() === wanted.toLowerCase();
    });
    if (match) select.value = match.value;
    var messageField = form.elements['message'];
    if (messageField && !messageField.value) {
      messageField.value = 'I would like to book: ' + (match ? match.textContent : wanted) + '\n\n';
    }
  })();

  function clearErrors() {
    Array.prototype.forEach.call(form.querySelectorAll('[aria-invalid]'), function (f) {
      f.removeAttribute('aria-invalid');
    });
    Array.prototype.forEach.call(form.querySelectorAll('[data-error-for]'), function (n) {
      n.parentNode.removeChild(n);
    });
  }

  function showFieldErrors(errors) {
    var first = null;
    Object.keys(errors).forEach(function (name) {
      var field = form.elements[name];
      if (!field) return;
      field.setAttribute('aria-invalid', 'true');
      var msg = document.createElement('span');
      msg.setAttribute('data-error-for', name);
      msg.style.cssText = 'display:block;color:#a12a1f;font-size:0.9em;margin-top:0.25rem';
      msg.textContent = errors[name];
      field.parentNode.insertBefore(msg, field.nextSibling);
      if (!first) first = field;
    });
    if (first) first.focus();
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    clearErrors();

    var payload = {};
    new FormData(form).forEach(function (value, key) { payload[key] = value; });

    statusEl.textContent = 'Sending\u2026';
    if (button) button.disabled = true;

    fetch('/api/inquiry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) { return { status: r.status, body: j }; });
      })
      .then(function (res) {
        if (res.status === 201 && res.body.ok) {
          form.reset();
          statusEl.textContent = 'Thank you. We have your inquiry and will reply by email.';
          return;
        }
        if (res.body.errors) {
          statusEl.textContent = 'Please fix the highlighted fields.';
          showFieldErrors(res.body.errors);
          return;
        }
        statusEl.textContent = res.body.error || 'Something went wrong. Please try again.';
      })
      .catch(function () {
        statusEl.textContent = 'We could not reach the server. Check your connection and try again.';
      })
      .then(function () { if (button) button.disabled = false; });
  });
})();
