(function () {
  'use strict';

  var IMG_BASE = 'https://commons.wikimedia.org/wiki/Special:FilePath/';
  var PAGE_BASE = 'https://commons.wikimedia.org/wiki/File:';
  var WIDTHS = [480, 800, 1200];

  var grid = document.getElementById('grid');
  var route = document.getElementById('route');
  var status = document.getElementById('status');
  var dlg = document.getElementById('lb');
  var lbImg = document.getElementById('lb-img');
  var lbTitle = document.getElementById('lb-title');
  var lbMeta = document.getElementById('lb-meta');
  var lbCredit = document.getElementById('lb-credit');

  var data = { stops: [], images: [] };
  var current = 'all';
  var visible = [];
  var lbIndex = 0;

  function fileKey(file) { return encodeURIComponent(file.replace(/ /g, '_')); }
  function srcFor(file, w) { return IMG_BASE + fileKey(file) + '?width=' + w; }
  function pageFor(file) { return PAGE_BASE + fileKey(file); }
  function stopName(id) {
    for (var i = 0; i < data.stops.length; i++) if (data.stops[i].id === id) return data.stops[i].name;
    return '';
  }

  function load() {
    return fetch('/api/gallery', { headers: { Accept: 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error('api ' + r.status); return r.json(); })
      .catch(function () {
        // API not available (plain static hosting): fall back to the JSON file.
        return fetch('data/gallery.json').then(function (r) {
          if (!r.ok) throw new Error('json ' + r.status);
          return r.json();
        });
      });
  }

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') n.textContent = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }

  function buildRoute() {
    var items = [{ id: 'all', name: 'All places', note: data.images.length + ' photographs' }].concat(data.stops);
    route.textContent = '';
    items.forEach(function (s) {
      var count = s.id === 'all' ? data.images.length : data.images.filter(function (i) { return i.stop === s.id; }).length;
      if (!count) return;
      var b = el('button', { type: 'button', 'class': 'stop', 'data-stop': s.id, 'aria-pressed': String(s.id === current) });
      b.appendChild(document.createTextNode(s.name));
      b.appendChild(el('small', { text: count + (count === 1 ? ' photo' : ' photos') }));
      b.addEventListener('click', function () { setStop(s.id); });
      route.appendChild(el('li', {}, [b]));
    });
  }

  function setStop(id, skipHash) {
    current = id;
    Array.prototype.forEach.call(route.querySelectorAll('.stop'), function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-stop') === id));
    });
    if (!skipHash && window.history && history.replaceState) {
      history.replaceState(null, '', id === 'all' ? location.pathname + location.search : '#' + id);
    }
    render();
  }

  function render() {
    visible = data.images.filter(function (i) { return current === 'all' || i.stop === current; });
    grid.textContent = '';

    visible.forEach(function (img, idx) {
      var image = el('img', {
        src: srcFor(img.file, 800),
        srcset: WIDTHS.map(function (w) { return srcFor(img.file, w) + ' ' + w + 'w'; }).join(', '),
        sizes: '(max-width: 30rem) 100vw, (max-width: 52rem) 50vw, 33vw',
        alt: img.alt || img.title,
        loading: idx < 3 ? 'eager' : 'lazy',
        decoding: 'async'
      });
      if (img.w && img.h) { image.setAttribute('width', img.w); image.setAttribute('height', img.h); }

      var btn = el('button', { type: 'button', 'class': 'tile-btn', 'aria-label': 'View larger: ' + img.title }, [image]);
      btn.addEventListener('click', function () { openLightbox(visible.indexOf(img)); });

      var cap = el('figcaption', {}, [
        el('span', { 'class': 't', text: img.title }),
        el('span', { 'class': 'p', text: stopName(img.stop) })
      ]);

      var li = el('li', { 'class': 'tile' }, [el('figure', {}, [btn, cap])]);

      // A dead image link never leaves a broken box on the page.
      image.addEventListener('error', function () {
        console.warn('[gallery] image failed to load:', img.file);
        if (li.parentNode) li.parentNode.removeChild(li);
        var i = visible.indexOf(img);
        if (i > -1) visible.splice(i, 1);
        var j = data.images.indexOf(img);
        if (j > -1) data.images.splice(j, 1);
        buildRoute(); // keeps the per-stop photo counts honest
        updateStatus();
      });

      grid.appendChild(li);
    });

    updateStatus();
  }

  function updateStatus() {
    if (!visible.length) {
      status.textContent = '';
      grid.appendChild(el('li', { 'class': 'empty', text: 'No photographs to show for this stop yet.' }));
      return;
    }
    var label = current === 'all' ? 'all places' : stopName(current);
    var note = '';
    data.stops.forEach(function (s) { if (s.id === current) note = ' ' + s.note + '.'; });
    status.textContent = 'Showing ' + visible.length + (visible.length === 1 ? ' photograph' : ' photographs') + ' from ' + label + '.' + note;
  }

  /* ---------- Lightbox ---------- */

  function fillLightbox() {
    var img = visible[lbIndex];
    if (!img) return;
    lbImg.src = srcFor(img.file, 1200);
    lbImg.alt = img.alt || img.title;
    lbTitle.textContent = img.title;
    lbMeta.textContent = stopName(img.stop) + ' \u2014 ' + (lbIndex + 1) + ' of ' + visible.length;
    lbCredit.textContent = '';
    lbCredit.appendChild(document.createTextNode((img.credit ? 'Photo: ' + img.credit + '. ' : 'Photo from Wikimedia Commons. ')));
    var a = el('a', { href: pageFor(img.file), target: '_blank', rel: 'noopener noreferrer', text: 'Author and licence' });
    lbCredit.appendChild(a);

    // Warm the neighbours so arrow keys feel instant.
    [lbIndex - 1, lbIndex + 1].forEach(function (i) {
      if (visible[i]) { var p = new Image(); p.src = srcFor(visible[i].file, 1200); }
    });
  }

  function openLightbox(idx) {
    lbIndex = idx;
    fillLightbox();
    if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open', '');
  }
  function step(d) {
    if (!visible.length) return;
    lbIndex = (lbIndex + d + visible.length) % visible.length;
    fillLightbox();
  }
  function closeLightbox() { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); }

  document.getElementById('lb-prev').addEventListener('click', function () { step(-1); });
  document.getElementById('lb-next').addEventListener('click', function () { step(1); });
  document.getElementById('lb-close').addEventListener('click', closeLightbox);
  dlg.addEventListener('click', function (e) { if (e.target === dlg) closeLightbox(); });
  dlg.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowLeft') { e.preventDefault(); step(-1); }
    if (e.key === 'ArrowRight') { e.preventDefault(); step(1); }
  });

  /* ---------- Start ---------- */

  load()
    .then(function (d) {
      data = d;
      buildRoute();
      var hash = location.hash.replace('#', '');
      var valid = data.stops.some(function (s) { return s.id === hash; });
      setStop(valid ? hash : 'all', true);
      window.addEventListener('hashchange', function () {
        var h = location.hash.replace('#', '');
        var ok = data.stops.some(function (s) { return s.id === h; });
        if ((ok ? h : 'all') !== current) setStop(ok ? h : 'all', true);
      });
    })
    .catch(function (err) {
      console.error('[gallery] could not load gallery data:', err);
      status.textContent = 'The gallery could not be loaded. Refresh the page, or contact us if it keeps happening.';
    });
})();
