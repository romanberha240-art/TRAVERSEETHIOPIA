# Traverse Ethiopia: fixes pack

Drop these files into the root of the repo (same level as `index.html`). Nothing here overwrites your
existing `css/` or `js/` files: new files are named `gallery-v2.*` and `inquiry-form.js`.

## What is in it

| File | What it does |
| --- | --- |
| `gallery.html`, `css/gallery-v2.css`, `js/gallery-v2.js` | New gallery page. Real photographs, filter by stop, keyboard-friendly viewer, dead images are dropped instead of showing a broken box. **Replaces your current `gallery.html`.** |
| `data/gallery.json` | The photo list. 14 real photographs from Wikimedia Commons (Lalibela, Simien/highlands, Blue Nile Falls, Danakil). This is the "database" for the gallery. |
| `server.js`, `lib/handlers.js` | Backend for Railway or any Node host. Serves the site plus `/api/gallery`, `/api/inquiry`, `/api/health`. No npm dependencies. |
| `api/gallery.js`, `api/inquiry.js`, `api/health.js` | The same backend as Vercel functions. Vercel picks up the `api/` folder automatically. |
| `js/inquiry-form.js`, `contact-form-snippet.html` | A working contact / trip-inquiry form wired to `/api/inquiry`. |
| `scripts/check-links.js` | Scans every `.html`/`.css` file for broken links, missing images, dead `#anchors`, `<img>` without alt, and placeholder-image hosts (picsum, placehold, etc.). |
| `scripts/verify-images.js` | Checks that every gallery photo still loads (needs internet). |

## Steps

1. Copy everything into the repo root. Accept the replacement of `gallery.html`.
2. Add these to `package.json` (keep your existing entries):
   ```json
   "scripts": {
     "start": "node server.js",
     "check:links": "node scripts/check-links.js",
     "check:images": "node scripts/verify-images.js"
   },
   "engines": { "node": ">=18" }
   ```
3. Run `npm run check:links`. It lists every broken link and image in the site so you can fix each one, including any
   image that is not a real Ethiopia photo (it flags placeholder hosts). Run `npm run check:images` with internet on.
4. In `contact.html`, replace the form with `contact-form-snippet.html` and add
   `<script src="js/inquiry-form.js" defer></script>` before `</body>`.
5. Set the inquiry destination (at least one) in Railway or Vercel environment variables:

   | Variable | Purpose |
   | --- | --- |
   | `RESEND_API_KEY`, `INQUIRY_FROM_EMAIL`, `INQUIRY_TO_EMAIL` | Emails each inquiry to you through Resend. |
   | `INQUIRY_WEBHOOK_URL` | Posts each inquiry as JSON to Formspree, Make, Zapier, Slack, etc. |
   | `INQUIRY_FILE` | Railway/VPS only: path on a persistent volume. Default `data/inquiries.jsonl`. |

   Vercel's disk is read-only, so on Vercel you must set the email or webhook variables. With none set, the form
   tells the visitor it could not save the inquiry instead of pretending it worked.

## Tested

- Server: health, gallery filter, valid/invalid inquiry, spam trap, rate limit (5 per 10 min per IP), oversized body,
  wrong methods, and blocked access to `server.js`, `lib/`, `.git`, `package.json`, stored inquiries and path traversal.
- Vercel handlers with mocked requests.
- Gallery page in a headless browser: filter, deep links (`gallery.html#danakil`), viewer with arrow keys and Escape,
  a failing image is removed, no horizontal scroll at 390px wide.
- Not tested here: live loading of the Wikimedia images (the test environment has no internet) and real email delivery.

## Second pass (added on top of the original pack)

- Added two new stops to `data/gallery.json`: **Bale Mountains** (an Ethiopian wolf on the Sanetti Plateau) and
  **Omo Valley** (the Omo River, the valley landscape, and a portrait from the Hamer tribe near Turmi). All three
  files are real, verified Wikimedia Commons photos — not placeholders.
- Added "Bale Mountains trek" and "Omo Valley cultural tour" to the tour dropdown in `contact-form-snippet.html`.
- `js/inquiry-form.js` now reads a `?tour=` URL parameter and pre-selects that tour (and drafts the message) when the
  form loads. This is what makes an itinerary "bookable": put a button on each itinerary page that links to
  `contact.html?tour=Bale%20Mountains%20trek`, and the visitor lands on a form ready to submit for that trip.

## Limits you should know about

- I still have not seen your other HTML/CSS/JS (`index.html`, `destination.html`, `birding-tours.html`,
  `cultural-tours.html`, `about.html`, `contact.html`, and any itinerary pages). This pack cannot fix buttons, links,
  or images on pages it has never seen. Run `npm run check:links` after merging this in — it will scan those pages
  too and list everything broken. Send me those files (or the whole repo as a ZIP) and I can go through them directly.
- Bale Mountains and Omo Valley each have only 1-3 photos so far, verified real but a thin start. Gondar, Axum, Harar,
  birding and coffee still need entries too. Add more to `data/gallery.json` using the exact Commons file name, add a
  new entry to `stops` if it's a new place, then run `npm run check:images` (needs internet) before publishing.
- Photos are linked from Wikimedia Commons under open licences. Each photo has an "Author and licence" link in the viewer.
  For a commercial site, check each file page and credit as required, or download the originals into `img/` and
  self-host them.
- The inquiry form is a booking *request*, not a payment/date-availability system. To take real payments or block out
  dates, you'd need a booking backend (e.g. Stripe Checkout plus a calendar of availability) on top of this.
