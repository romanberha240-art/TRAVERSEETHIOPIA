'use strict';

const { handleInquiry } = require('../lib/handlers');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  }
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  const { status, json } = await handleInquiry({ body: req.body, ip });
  res.setHeader('Cache-Control', 'no-store');
  res.status(status).json(json);
};
